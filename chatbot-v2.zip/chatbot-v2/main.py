def main():
    print("Hello from chatbot!")


if __name__ == "__main__":
    main()
